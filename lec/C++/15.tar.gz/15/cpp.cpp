#include <iostream>
	
using namespace std;
	
int main(void)
{
	cout << "Hello C double Plus " << endl;
	
	return 0;
}
