#include <iostream>

using namespace std;

int main(void)
{
	int n1 = 3;
	float n2 = 3.7f;
	double n3 = 7.3;
	
	cout << "n1 = " << n1 << ", n2 = " << n2 << ", n3 =" << n3 << endl;
	
	
	return 0;
}
