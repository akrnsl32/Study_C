#include <stdio.h>

int main(void)
{
	printf("hello C Language \n");
	return 0;
	
}


