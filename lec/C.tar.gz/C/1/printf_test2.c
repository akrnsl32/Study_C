#include <stdio.h>

int main(void)
{
	printf("this is char : %c\n" , 65);
	printf("this is integer : %d\n" , 3);
	printf("this is floating point : %f\n" , 3.3f);
	printf("this is double : %lf\n" , 7.7);
	
	return 0;

}
