#include <stdio.h>

int main(void)
{
	int num1 = 10;
	int num2 = 2;
	
	printf("num1 + num2 = %d\n", num1 & num2);
	
	return 0;

}
