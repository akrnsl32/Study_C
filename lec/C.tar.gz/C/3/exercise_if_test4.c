#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>







int main(void)
{
	int num;
	
	srand(time(NULL));
		
	num = init_num();

	return 0;
}
