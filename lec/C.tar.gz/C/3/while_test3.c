#include <stdio.h>

int main(void)
{
	while(1)
		printf("hi\n");
		
	return 0;
}
