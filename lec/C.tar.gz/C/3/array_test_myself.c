#include <time.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	
	int freq_num[100] = {0};
	int freq_tab[11] = {0};

	int max_tab[5] = {0}; 	


	



	return 0;
}

