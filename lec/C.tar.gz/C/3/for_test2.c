#include <stdio.h>

int main(void)
{
	for(;;)
		printf("HI\n");
	return 0;

}
